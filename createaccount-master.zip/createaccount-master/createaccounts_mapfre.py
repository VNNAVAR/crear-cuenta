import sys
import boto3
import time

def create_accounts(start, n_accounts, alias_prefix):

    account_ids = []
    accounts = {}
    accounts['Accounts'] = []

    organizations = boto3.client('organizations')

    for i in range(start,start + n_accounts):

        if  i > 99:
            break
        
        account_number = "{0:02d}".format(i)
        alias = alias_prefix + account_number
        email = alias + '@mapfre.com'

        response = organizations.create_account(
            Email = email,
            AccountName = alias
        )

        request_id = response['CreateAccountStatus']['Id']
        status = response['CreateAccountStatus']['State']

        log('Creating account: ' + alias)
        log('With email: ' + email)
        while status == 'IN_PROGRESS':
            time.sleep(5)
            response = organizations.describe_create_account_status(
                CreateAccountRequestId = request_id
            )
            status = response['CreateAccountStatus']['State']

        log('Account creation status: ' + status)

        if status == 'FAILED':
            log('Failure reason: ' + response['CreateAccountStatus']['FailureReason'])
        else:
            account_id = response['CreateAccountStatus']['AccountId']
            account_ids.append(account_id)
            account = {
                "Id": account_id,
                "Email": email,
                "Name": alias,
                "Alias": alias
            }
            log(account)
            accounts['Accounts'].append(account)
            log('Account id: ' + account_id + '\n')


def log(message):
    print(message)

def usage(strError):
    log(strError)
    log("create-accounts.py <alias-prefix> <number-of-accounts> [<start>]")
    exit()

# We expect to receive two command line parameters:
# - The number of accounts to be created (required)
# - The alias prefix for the new accounts (required)
if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage('You must specify the alias prefix for the accounts')

    alias_prefix = sys.argv[1]

    if len(sys.argv) < 3:
        usage('You must specify the number of accounts to be created')

    try:
        n_accounts = int(sys.argv[2])
    except:
        n_accounts = -1

    if n_accounts < 1:
        usage('The number of accounts must be a valid integer greater than 0')
    
    start = 1
    if len(sys.argv) > 3:
        try:
            start = int(sys.argv[3])
        except:
            start = -1

    if start < 1:
        usage('Start must be a valid integer greater than 0')
    elif start + n_accounts > 100:
        usage('Max account index is 99')
    
    create_accounts(start,n_accounts,alias_prefix)